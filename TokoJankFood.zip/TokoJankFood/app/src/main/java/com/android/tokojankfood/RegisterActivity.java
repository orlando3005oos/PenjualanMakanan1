package com.android.tokojankfood;

public class RegisterActivity {
}
